import psycopg2
from config import host, user, password, db_name , port


try:
    connection = psycopg2.connect(
        host=host,
        user=user,
        password=password,
        database=db_name, 
        port=port
    )
    connection.autocommit = True
    
    
    #with connection.cursor() as cursor:
    #    cursor.execute(
    #        "SELECT version();"
    #    )
    
    #with connection.cursor() as cursor:
    #    cursor.execute(
    #        "CREATE table tasks(year varchar,region varchar,value int)"
    #    )
    #    print("[INFO] Table created succsfely")
        
    #    with connection.cursor() as cursor:
    #        cursor.execute(
    #        " INSERT INTO tasks(year , region,value ) VALUES ('1246', 'Bozak','100')"
    #        )
                        
    #    print("[INFO] Data was succesfuly inserted")
    #    print(f"Server version: {cursor.fetchone()}")

        #with connection.cursor() as cursor:
        #    cursor.execute(
        #    " SELECT region FROM tasks WHERE year='1246';"
        #    )
        #    print(cursor.fetchone())
        
        #with connection.cursor() as cursor:
        #    cursor.execute(
        #    "  DROP TABLE tasks"
        #    )
        #    print("[INFO] Table")


    with connection.cursor() as cursor:
        cursor.execute(
        " UPDATE tasks SET region = 'Sarai-al-Mahrusan'")
        print("[INFO] Table")
except Exception as _ex:
    print("[INFO] Error while working with PostgreSQL", _ex)
finally:
    if connection:
        connection.close()
        print("[INFO] PostgreSQL connection closed")